# script.securitycams
Kodi Securitycams Webcam Addon

You need to fill in all cams. Just add mjpeg streams!


You can use the Android App "IP Webcam" with the URL http://IPAddress:8080/shot.jpg for testing.